<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\cseo_options_settings;
use App\cseo_reward;
use App\cseo_merchant;

use DB;
use URL;
use Validator;
use Redirect;

class RewardController extends Controller
{
    /**
        * Create a new controller instance.
        *
        * @return void
        */
       public function __construct()
       {
           $this->middleware('auth');
           $this->middleware('logged');
       }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $merchant = cseo_merchant::where('merchant_name', URL::to('/'))->first();

        $title = cseo_options_settings::SELECT('site_identity')->where('merchants_id', $merchant->id)->first();

         if ( count( $title ) > 0 ) {
             $site_identity = json_decode( $title->site_identity);
         }

        $query = [];


        if(request()->has('search')){    
            
        $search = request('search');   

        $reward = cseo_merchant::SELECT(DB::raw('cseo_merchants.merchant_name,cseo_merchants.id, (select amount from cseo_rewards where placereward = 1 and cseo_rewards.merchants_id = cseo_merchants.id ) amount_one,(select amount from cseo_rewards where placereward = 2 and cseo_rewards.merchants_id = cseo_merchants.id ) amount_two,(select amount from cseo_rewards where placereward = 3 and cseo_rewards.merchants_id = cseo_merchants.id ) amount_three'))->where('cseo_merchants.merchant_name', 'like', '%'.$search.'%')->orderBy('cseo_merchants.merchant_name','asc')->latest();

          $query['search'] = request('search');   

        }else{

        $reward = cseo_merchant::SELECT(DB::raw('cseo_merchants.merchant_name,cseo_merchants.id, (select amount from cseo_rewards where placereward = 1 and cseo_rewards.merchants_id = cseo_merchants.id ) amount_one,(select amount from cseo_rewards where placereward = 2 and cseo_rewards.merchants_id = cseo_merchants.id ) amount_two,(select amount from cseo_rewards where placereward = 3 and cseo_rewards.merchants_id = cseo_merchants.id ) amount_three'))->orderBy('cseo_merchants.merchant_name','asc')->latest();

        }

        $reward = $reward->paginate(10)->appends($query);

         return view('system.reward.index', compact('site_identity', 'reward'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
            $reward = new cseo_reward;

            $validate = Validator::make($request->all(), [
                    //'placereward'=>'required|unique:cseo_rewards',                   
                    'placereward'=>'required',                   
                    ]);
               
            if ($validate->fails()){
                    return Redirect::back()->withErrors($validate)->withInput()->setStatusCode(422);    
            }else{

                $reward->placereward = $request->placereward;
                $reward->amount = $request->amount;
                $reward->merchants_id = $request->merchant;
                $reward->save();

                session()->flash('message', 'Successfully Added');
                return response()->json(['message' => 'Successfully Added']);
            }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        
        $merchant = cseo_merchant::where('merchant_name', URL::to('/'))->first();

        $title = cseo_options_settings::SELECT('site_identity')->where('merchants_id', $merchant->id)->first();

        if ( count( $title ) > 0 ) {
           $site_identity = json_decode( $title->site_identity);
        }

        $query = [];


        $merchant = cseo_merchant::find($id);

        $reward = cseo_reward::where('merchants_id', $id)->get();
    
        return view('system.reward.edit', compact('site_identity','reward', 'merchant'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $reward = cseo_reward::find($id);

                  $validate = Validator::make($request->all(), [
                          'placereward'=>'required',                   
                          ]);
                     
                  if ($validate->fails()){
                          return Redirect::back()->withErrors($validate)->withInput()->setStatusCode(422);    
                  }else{

                      $reward->placereward = $request->placereward;
                      $reward->amount = $request->amount;
                      $reward->save();

                      session()->flash('message', 'Successfully Updated');
                      return response()->json(['message' => 'Successfully Updated']);
                  }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
