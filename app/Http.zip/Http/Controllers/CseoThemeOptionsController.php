<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Response;

use DB;
use URL;
use Image;
use Storage;
use File;
use Validator;
use Redirect;

use App\cseo_account;
use App\cseo_pages;
use App\cseo_media;
use App\cseo_options_settings;
use App\cseo_theme_options;
use App\cseo_merchant;

class CseoThemeOptionsController extends Controller 
{

    public $user;

        /**
       * Create a new controller instance.
       *
       * @return void
       */
      public function __construct()
      {
          $this->middleware('auth');
          $this->middleware('logged');

          $this->middleware(function ($request, $next) {

           $this->user = cseo_account::where('id', auth()->user()->id)->first();
       
               if($this->user->status_id == '4'){
                   return redirect('/403');
               }else{
                   return $next($request); 
                   
               }

            });

      }


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $relPath = 'css/front-customize.css';
        if (!file_exists($relPath)) {
            mkdir($relPath, 777, true);
        }

      $merchant = cseo_merchant::where('merchant_name', URL::to('/'))->first();

        $theme_settings = new cseo_theme_options;
        $theme_group = cseo_merchant::select( DB::raw('cseo_merchants.id as theme_merchant_id,cseo_merchants.merchant_name as merchant_name,cseo_merchants.id as merchants_id,cseo_theme_options.merchants_id as merchant_theme_opt,cseo_theme_options.updated_at as updated_at, cseo_options_settings.maintenance_mode') )->leftjoin('cseo_theme_options', 'cseo_merchants.id', '=', 'cseo_theme_options.merchants_id')->join('cseo_options_settings', 'cseo_options_settings.merchants_id', 'cseo_merchants.id')->orderby('cseo_theme_options.created_at', 'desc')->get();

        $theme_count = $theme_group->count(); 

        if(Auth::user()->status_id != "4" ){

            $media = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('view_stat','0')->latest('cseo_media.created_at')->get();

        }else{

            $media = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('view_stat','0')->where('merchants_id',$merchant->id)->latest('cseo_media.created_at')->get();
        }


        $logo_settings = cseo_theme_options::select( DB::raw( 'cseo_theme_options.identity_img as identity_img,cseo_theme_options.footer_link_opt as footer_link_opt,cseo_theme_options.footer_copyright_opt as footer_copyright_opt' ) )->first();

        $title = cseo_options_settings::SELECT('site_identity')->where('merchants_id', $merchant->id)->first();
        $merchats_quwey = cseo_options_settings::where('merchants_id', $theme_group[0]->merchant_theme_opt)->get();

        if ( count( $title ) > 0 ) {
            $site_identity = json_decode( $title->site_identity);
        }
      return view('system.appearance.theme-settings.theme-settings', compact('site_identity','media','theme_group','merchats_quwey', 'theme_count'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(){
        // 
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request){



    }
    
    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id){

        $merchant = cseo_merchant::where('merchant_name', URL::to('/'))->first();

        $title = cseo_options_settings::SELECT('site_identity')->where('merchants_id', $merchant->id)->first();

        if ( count( $title ) > 0 ) {
           $site_identity = json_decode( $title->site_identity);
        }

        $theme_group = cseo_theme_options::select( DB::raw('cseo_theme_options.id as id,cseo_theme_options.merchants_id as merchant_id,cseo_theme_options.identity_img as identity_img,cseo_theme_options.familyHead_opt as familyHead_opt,cseo_theme_options.fontsHead_opt as fontsHead_opt,cseo_theme_options.familyContent_opt as familyContent_opt,cseo_theme_options.fontContent_opt as fontContent_opt,cseo_theme_options.color_opt as color_opt,cseo_theme_options.menu_color_opt as menu_color_opt,cseo_theme_options.m_menu_color_opt as m_menu_color_opt,cseo_theme_options.bgAttrib_opt as bgAttrib_opt,cseo_theme_options.bgcoloritem_opt as bgcoloritem_opt,cseo_theme_options.bgimgitem_opt as bgimgitem_opt,cseo_theme_options.footer_link_opt as footer_link_opt,cseo_theme_options.footer_copyright_opt as footer_copyright_opt,cseo_theme_options.currstatus_opt as currstatus_opt,cseo_theme_options.status_opt as status_opt,cseo_pages.merchants_id as merchants_id,cseo_pages.page_title as page_title,cseo_pages.page_content as page_content,cseo_options_settings.site_identity as site_identity,cseo_options_settings.site_url as merchant_name,cseo_options_settings.ranking as ranking,cseo_options_settings.data_sitekey as data_sitekey ,cseo_options_settings.data_secretkey as data_secretkey, cseo_options_settings.maintenance_mode as main_m') )->leftjoin('cseo_pages', 'cseo_pages.merchants_id', '=', 'cseo_theme_options.id')->leftjoin('cseo_options_settings', 'cseo_options_settings.merchants_id', '=', 'cseo_theme_options.id')->where('cseo_theme_options.merchants_id', $id)->where('cseo_pages.status_id', '15')->orderby('cseo_theme_options.created_at', 'desc')->get();

        
        if(Auth::user()->status_id != "4" ){

            $media = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('view_stat','0')->latest('cseo_media.created_at')->get();

        }else{

            $media = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('view_stat','0')->where('merchants_id',$merchant->id)->latest('cseo_media.created_at')->get();
        }
     

        if ( count( $theme_group ) > 0 ) {
            $identity_img = json_decode($theme_group[0]->identity_img);
            $bgimg = json_decode($theme_group[0]->bgimgitem_opt);
        }
     
        $merchants = cseo_merchant::latest()->get();
        if ( count( $identity_img ) > 0) {
            if ($identity_img->identity_logo > 2) {
                $logo = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('cseo_media.id', $identity_img->identity_logo)->first();
            }else{
                $logo = '0';
            }
            if ($identity_img->identity_icon > 2) {
                $icon = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('cseo_media.id', $identity_img->identity_icon)->first();
            }else{
                $icon = '0';
            }

            if ($identity_img->identity_banner > 2) {
                $banner = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('cseo_media.id', $identity_img->identity_banner)->first();
            }else{
                $banner = '0';
            }
        }

        if ( count( $bgimg ) > 0 ) {
            if ($bgimg->bg_image_url > 2) {
                $bgimg = cseo_media::SELECT(DB::raw('cseo_media.id,cseo_media.title_name,cseo_media.media_thumbnail,cseo_media.media_name,cseo_media.created_at,cseo_media.file_size,cseo_media.caption_text,cseo_media.alt_text,cseo_media.description,cseo_merchants.merchant_name'))->join('cseo_merchants', 'cseo_merchants.id', 'cseo_media.merchants_id')->where('cseo_media.id', $bgimg->bg_image_url)->first();
            }else{
                $bgimg = '0';
            }
        }





         
        return view( 'system.appearance.theme-settings.edit', compact('theme_group','logo','icon','banner','bgimg','merchants','site_identity','media'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id){

        $relPath = asset('css/front-customize.css');
        if (!file_exists($relPath)) {
            mkdir($relPath, 777, true);
        }
        
        //Collect all the data request
        
        //$site_url = $request->site_id;
        $site_url = $request->site_url;

        $merchant_id = $request->merchant_id;
        $media_logo = $request->media_logo;
        $media_banner = $request->media_banner;
        $site_title = $request->site_title;
        $site_tag_line = $request->site_tag_line;
        $site_display_assets = $request->site_display_assets;
        $media_icon = $request->media_icon;
        $familyHead_opt = $request->familyHead_opt;
        $font_size_heading = $request->font_size_heading;
        $font_style_heading = $request->font_style_heading;
        $font_weight_heading = $request->font_weight_heading;
        $familyContent_opt = $request->familyContent_opt;
        $font_size_content = $request->font_size_content;
        $font_style_content = $request->font_style_content;
        $font_weight_content = $request->font_weight_content;
        $colorElementHeading = $request->colorElementHeading;
        $color_menu_wrap = $request->colorElementMenuColorWrap;
        $color_menu_text = $request->colorElementMenuColorText;
        $color_menu_hover = $request->colorElementMenuColorHover;
        $color_m_menu_btn = $request->colorElementMenuColorMobileBtn;
        $color_m_menu_icon = $request->colorElementMenuColorMobileBtnIcon;
        $color_m_menu_hover = $request->colorElementMenuColorMobileBtnHover;
        $colorElementDefaultColor = $request->colorElementDefaultColor;
        $bgAttrib_opt = $request->bgAttrib_opt;
        $bgcoloritem_opt = $request->bgcoloritem_opt;

        $bgimageitem_opt = $request->bgimageitem_opt;
        $site_fp_presets = $request->site_fp_presets;
        $site_fp_position = $request->site_fp_position;
        $site_fp_repeat = $request->site_fp_repeat;
        $site_fp_scroll = $request->site_fp_scroll;
        $site_fp_size = $request->site_fp_size;

        $site_fp_title = $request->site_fp_title;
        $site_fp_editor = $request->site_fp_editor;
        $google_ranking = $request->google_ranking;
        $google_g_key = $request->google_gkey;
        $google_s_key = $request->google_skey;
        $maintenance = $request->maintenance_mode;


        $site_fp_ft_copyright = html_entity_decode($request->site_fp_ft_copyright);
        $site_fp_ft_target = $request->site_fp_ft_target;
        $site_fp_ft_rel = $request->site_fp_ft_rel;

        //site_identity
        $site_identity = '{"site_title":"' . $site_title . '","site_display_assets":"' . $site_display_assets . '","site_tag_line":"' . $site_tag_line . '"}';

        //image
        $identity_img = '{"identity_logo":"' . $media_logo . '","identity_icon":"' . $media_icon . '","identity_banner":"' . $media_banner . '"}';

        //heading-fonts
        $fontsHead_opt = '{"size":"' . $font_size_heading . '","style":"' . $font_style_heading . '","weight":"' . $font_weight_heading . '"}';

        //content-fonts
        $fontContent_opt = '{"size":"' . $font_size_content . '","style":"' . $font_style_content . '","weight":"' . $font_weight_content . '"}';

        //color
        $color_opt = '{"head":"' . $colorElementHeading . '","default":"' . $colorElementDefaultColor . '"}';

        //menu color
        $menu_color_opt = '{"wrap":"' . $color_menu_wrap . '","text":"' . $color_menu_text . '","hover":"' . $color_menu_hover . '"}';

        //mobile menu color
        $m_menu_color_opt = '{"btn_wrap":"' . $color_m_menu_btn . '","icon":"' . $color_m_menu_icon . '","hover":"' . $color_m_menu_hover . '"}';

        //background-image
        $bgimgitem_opt = '{"bg_image_url":"' . $bgimageitem_opt . '","presets":"' . $site_fp_presets . '","position":"' . $site_fp_position . '","repeat":"' . $site_fp_repeat . '","scroll":"' . $site_fp_scroll . '","size":"' . $site_fp_size . '"}';

        //footer
        $footer_link_opt = '{"link_name_opt":"' . $site_url . '","link__opt":"' . $site_url . '","link_title_opt":"' . $site_url . '","link_target_opt":"' . $site_fp_ft_target . '","link_rel_opt":"' . $site_fp_ft_rel . '"}';


        $theme_opt = new cseo_theme_options;

        //Check the Rules
        $rules = ['site_url' => 'required', 'google_ranking'=> 'required', 'google_gkey'=> 'required' , 'google_skey'=> 'required'];

        //Check messages
        $customMessages = ['required' => 'This :attribute is required' ];

        $validate = Validator::make($request->all(), $rules, $customMessages);

        if ( $validate->passes() ) {
            
            if ( count($id) > 0 ) {
                $theme_opt::where('id', $id)->update([
                    'identity_img' => $identity_img,
                    'familyHead_opt' => $familyHead_opt,
                    'fontsHead_opt' => $fontsHead_opt,
                    'familyContent_opt' => $familyContent_opt,
                    'fontContent_opt' => $fontContent_opt,
                    'color_opt' => $color_opt,
                    'menu_color_opt' => $menu_color_opt,
                    'm_menu_color_opt' => $m_menu_color_opt,
                    'bgAttrib_opt' => $bgAttrib_opt,
                    'bgcoloritem_opt' => $bgcoloritem_opt,
                    'bgimgitem_opt' => $bgimgitem_opt,
                    'footer_link_opt' => $footer_link_opt,
                    'footer_copyright_opt' => $site_fp_ft_copyright,
                    'status_opt' => 'revise',
                ]);

                $pages_opt = new cseo_pages;
                $rev_count = $id . '-revision-v1';
                $pages_opt::where('merchants_id', $id)->where('status_id', '15')->update([
                    'page_name' => $site_fp_title,
                    'page_title' => $site_fp_title,
                    'page_content' => $site_fp_editor,
                    'url_path' => "/".strtolower(str_replace(' ', '-', $site_url)),
                    'page_type' => 'front-page',
                    'rev_count' => '0',
                    'cseo_media_id' => '0',
                    'curr_status_id' => '15',
                    'user_id' => Auth::user()->id,
                    'created_at' => date('Y-m-d H:i:s'),
                    'updated_at' => date('Y-m-d H:i:s')
                ]);

                $options_opt = new cseo_options_settings;
                $options_opt::where( 'merchants_id', $id )->update([
                    'site_identity' => $site_identity,
                    'ranking' => $google_ranking,
                    'data_sitekey' => $google_g_key,
                    'data_secretkey' => $google_s_key,
                    'maintenance_mode' =>$maintenance,
                    'site_status' => 'updated',

                ]);
            }

            // $style = $theme_opt::select( DB::raw('cseo_theme_options.familyHead_opt as familyHead_opt,cseo_theme_options.fontsHead_opt as fontsHead_opt,cseo_theme_options.familyContent_opt as familyContent_opt,cseo_theme_options.fontContent_opt as fontContent_opt,cseo_theme_options.color_opt as color_opt,cseo_theme_options.menu_color_opt as menu_color_opt,cseo_theme_options.m_menu_color_opt as m_menu_color_opt,cseo_theme_options.bgAttrib_opt as bgAttrib_opt,cseo_theme_options.bgcoloritem_opt as bgcoloritem_opt,cseo_theme_options.bgimgitem_opt as bgimgitem_opt') )->where('merchants_id', $id)->first();


            // if (count( $style ) > 0 ) {
            //     $bg_image = json_decode($style->bgimgitem_opt);
            // }
            
            // $bg_image_id = cseo_media::where('id',$bg_image->bg_image_url)->first();

            // $data = view('layouts.sample',compact('style','bg_image_id'))->render();

            // //ob_start('ob_gzhandler'); //Capture all output into buffer
            // //$css = ob_get_clean(); // Store output in a variable, flush the buffer
            // $fileName = 'front-customize.css'; //Save it as css file
            // File::put(public_path('/css/'.$fileName),$data);
            // //File::put(asset('css/'.$fileName),$data);
           
            
            $redirect = url('/system/theme-settings/' . $id . '/edit' );

            return response()->json([
                'status'    => 'success',
                'message'   => 'Update the record',
                'type'      => 'publish',
                'redirect'  => $redirect
            ]);

        }else{
            return response()->json([
                'status'    => 'Error',
                'message'   => 'Please check the required field',
                'type'      => '',
                'error' => $validate->getMessageBag()->toArray(),
                'redirect'  => ''
            ]);
           // return Redirect::back()->withErrors($validate)->withInput()->setStatusCode(422);    

         }
     }
}
