<div class="col-lg-3">
        <div class="ibox float-e-margins">
                <div class="ibox-title">
                        <span class="label label-warning pull-right">Register</span>
                        <h5>Pending</h5>
                </div>
                <div class="ibox-content">
                        <h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countPending }} @else 0 @endif</h1>
                        <div class="stat-percent font-bold text-warning icons-stats"><i class="fa fa-5x fa-clock-o"></i></div>
                        <small>Total pending</small>
                </div>
        </div>
</div>
<div class="col-lg-3">
        <div class="ibox float-e-margins">
                <div class="ibox-title">
                        <span class="label label-danger pull-right">Register</span>
                        <h5>Disqualified</h5>
                </div>
                <div class="ibox-content">
                        <h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countDisqual }} @else 0 @endif</h1>
                        <div class="stat-percent font-bold text-danger icons-stats"><i class="fa fa-5x fa-times"></i></div>
                        <small>Total disqualified</small>
                </div>
        </div>
</div>
<div class="col-lg-3">
        <div class="ibox float-e-margins">
                <div class="ibox-title">
                        <span class="label label-success pull-right">Register</span>
                        <h5>Email Confirmed</h5>
                </div>
                <div class="ibox-content">
                        <h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countConfirm }} @else 0 @endif</h1>
                        <div class="stat-percent font-bold text-success icons-stats"><i class="fa fa-5x fa-envelope"></i></div>
                        <small>Total confirmed</small>
                </div>
        </div>
</div>
<div class="col-lg-3">
        <div class="ibox float-e-margins">
                <div class="ibox-title">
                        <span class="label label-info pull-right">Register</span>
                        <h5>Accepted</h5>
                </div>
                <div class="ibox-content">
                        <h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countApproved }} @else 0 @endif</h1>
                        <div class="stat-percent font-bold text-info icons-stats"><i class="fa fa-5x fa-check"></i></div>
                        <small>Total accepted</small>
                </div>
        </div>
</div>