@extends('layouts.master')

@section('title', $site_identity->site_title.' | Dashboard')

@section('breadcrumb')
    <h2><i class="fa fa-th-large"></i> Dashboard</h2>
@endsection

@section('admin-content')
        <div class="row  border-bottom white-bg dashboard-header">

                            <div class="col-md-3">
                                <h2>Welcome {{$user->display_name}}</h2>
                            </div>
                            <div class="col-md-6">
                            </div>
                            <div class="col-md-3">
                                <div class="statistic-box">
                                <h4>
                                    Search
                                </h4>
                                    <div class="m-t">
                                     <form id="search">
                                        {{csrf_field()}}   
                                       <select class="form-control m-b" id="team" name="team" onchange="filterDomain(this);"  >
                                           <option value="">--- Select Team ---</option>
                                           @foreach ($team as $teams)  
                                               <option value="{{$teams->id }}" class="text-center"> {{$teams->name }} </option>
                                           @endforeach
                                       </select>   
                                       <select class="form-control m-b" id="merchant" name="merchant" onchange="filterResult(this);">
                                           <option value="">--- Select Merchant ---</option>
                                           @foreach ($merchant_list as $merchants)  
                                           <option value="{{$merchants->id }}" class="text-center">{{str_replace('http://','',$merchants->merchant_name)}}</option>
                                           @endforeach
                                       </select>
                                       </form>      
                                    </div>

                                </div>
                            </div>
                    </div>    
    
    <div class="wrapper wrapper-content row">
           <div class="first-glance"> 
                <div class="col-lg-3">
                	<div class="ibox float-e-margins">
                		<div class="ibox-title">
                			<span class="label label-warning pull-right">Register</span>
                			<h5>Pending</h5>
                		</div>
                		<div class="ibox-content">
                			<h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countPending }} @else 0 @endif</h1>
                			<div class="stat-percent font-bold text-warning icons-stats"><i class="fa fa-5x fa-clock-o"></i></div>
                			<small>Total pending</small>
                		</div>
                	</div>
                </div>
                <div class="col-lg-3">
                	<div class="ibox float-e-margins">
                		<div class="ibox-title">
                			<span class="label label-danger pull-right">Register</span>
                			<h5>Disqualified</h5>
                		</div>
                		<div class="ibox-content">
                			<h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countDisqual }} @else 0 @endif</h1>
                			<div class="stat-percent font-bold text-danger icons-stats"><i class="fa fa-5x fa-times"></i></div>
                			<small>Total disqualified</small>
                		</div>
                	</div>
                </div>
                <div class="col-lg-3">
                	<div class="ibox float-e-margins">
                		<div class="ibox-title">
                			<span class="label label-success pull-right">Register</span>
                			<h5>Email Confirmed</h5>
                		</div>
                		<div class="ibox-content">
                			<h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countConfirm }} @else 0 @endif</h1>
                			<div class="stat-percent font-bold text-success icons-stats"><i class="fa fa-5x fa-envelope"></i></div>
                			<small>Total confirmed</small>
                		</div>
                	</div>
                </div>
                <div class="col-lg-3">
                	<div class="ibox float-e-margins">
                		<div class="ibox-title">
                			<span class="label label-info pull-right">Register</span>
                			<h5>Accepted</h5>
                		</div>
                		<div class="ibox-content">
                			<h1 class="no-margins">@if(count($status_register)>0) {{ $status_register->countApproved }} @else 0 @endif</h1>
                			<div class="stat-percent font-bold text-info icons-stats"><i class="fa fa-5x fa-check"></i></div>
                			<small>Total accepted</small>
                		</div>
                	</div>
                </div>
           </div>
    </div>

@endsection