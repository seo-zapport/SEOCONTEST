@extends('layouts.master')
@section('title', $site_identity->site_title.' | Contestant')
@section('breadcrumb')
	<h2><i class="fa fa-file-o"></i> Contestant</h2>
  <ol class="breadcrumb">
                   <li>
                        <a href="@if(Auth::user()->account_id =='1')/system/admin @else/system/user @endif">Dashboard</a>
                   </li>
                   <li class="active">
                       <strong>Contestant</strong>
                   </li>
            </ol>
@endsection
@section('admin-content')
    <div class="wrapper wrapper-content clearfix">
        <div class="ibox">
            <div class="ibox-title">
                <h5>Participants List</h5>
            </div>
            <div class="tabs-container ibox-content">
                <div id="Participants-Items">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="status">
                                        <ul class="nav">
                                            <li @if (app('request')->input('status_id')=='') class="active" @endif><a href="{{ url( '/system/contest' ) }}">All (@if(count($cseo_contest_count)>0){{$cseo_contest_count->countAll}}@else{{0}}@endif)</a></li>
                                            <li @if (app('request')->input('status_id')=='4') class="active" @endif><a href="{{ url( '/system/contest?status_id=4' ) }}">Pending (@if(count($cseo_contest_count)>0){{$cseo_contest_count->countPending}}@else{{0}}@endif)</a></li>
                                            <li @if (app('request')->input('status_id')=='5') class="active" @endif><a href="{{ url( '/system/contest?status_id=5' ) }}">Approved (@if(count($cseo_contest_count)>0){{$cseo_contest_count->countApproved}}@else{{0}}@endif)</a></li>
                                            <li @if (app('request')->input('status_id')=='6') class="active" @endif><a href="{{ url( '/system/contest?status_id=6' ) }}">Disqualified (@if(count($cseo_contest_count)>0){{$cseo_contest_count->countDisqualified}}@else{{0}}@endif)</a></li> 
                                            <li @if (app('request')->input('status_id')=='9') class="active" @endif><a href="{{ url( '/system/contest?status_id=9' ) }}">Trash (@if(count($cseo_contest_count)>0){{$cseo_contest_count->countTrash}}@else{{0}}@endif)</a></li> 
                                             
                                        </ul>
                                    </div>
                                </div> <!---.col-lg-12-->
                                <div class="col-md-3 pull-right">
                                    <!-- Search box  -->        
                                    <form role="form" class="form-horizontal pull-right"  method="get"  >
                                        <div class="input-group">
                                            <div class="input-group-btn">
                                                <button id="searchnow" type="submit" class="btn btn-primary searchnow"> Search </button>
                                            </div>
                                            <input type="text" class="form-control" id="search" name="search" placeholder="Search for ...">
                                            @if(!empty(app('request')->input('status_id')))  
                                                <input type="hidden" id="status_id" name="status_id" value="{{app('request')->input('status_id')}}"> 
                                            @endif
                                        </div>
                                    </form>
                                </div> 
                            </div> <!---.row-->
                            <div class="row">
                                <div class="col-md-5">
                                    <form role="form" class="form-horizontal col-md-5" method="post"> 
                                        {{csrf_field()}}         
                                        <div class="form-group">
                                            <div class="input-group">
                                                <select class="form-control m-b" id="bulkAction" name="bulkAction" required autofocus>
                                                    <option value=""> -Bulk Action- </option>
                                                </select> 
                                                <div class="input-group-btn">
                                                    <button id="btn-bulkActionConstest" type="button" class="btn btn-m btn-success btn-bulkActionConstest">Apply</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-md-3 pull-right">
                                    <p class="badge badge-info"><span>{{ $con_count }}</span> Item</p>
                                      @if(!empty(app('request')->input('search')))  
                                         Search results for <strong>"{{app('request')->input('search')}}"</strong>
                                     @endif 
                                </div>
                            </div> <!---.row-->
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover fixed" >
                                    <thead>
                                        <tr>
                                            <th class="text-center"><input type="checkbox" class="checkbox checkbox-info selectAll" id="selectAll"></th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Branding</th>
                                            <th>Url Website Contest</th>
                                            <th>Mobile no.</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    @if(count($register)>0)
                                        @foreach ($register as $registers)
                                            <tr class="gradeX table-item">
                                                <td style="width: 50px;" class="text-center"><input type="checkbox" class="checkbox checkbox-info" name="contestarr[]" value="{{$registers->reg_id}}"></td>
                                                <td class="hover">
                                                  <a href="#" class="modalView text-info" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" >{{ucfirst($registers->rname)}}<input type="hidden" id="Viewid" name="Viewid" value="{{$registers->reg_id}}"></a>
                                                    <strong>@if($registers->created_at >= \Carbon\Carbon::now()->subHour(24))<span class="badge badge-primary">New</span>@endif</strong>


                                                </td>
                                                <td>{{$registers->email}}</td>
                                                <td>{{$registers->merchant_name}}</td>
                                                <td>{{$registers->url_web_contest}}</td>
                                                <td>{{$registers->mobile_number}}</td>
                                                <td>@if($registers->verify_status =="0" && $registers->status_name == "Pending")
                                                    <p class="text-warning">Pending</p> 
                                                    @else  
                                                       @php 
                                                       if($registers->status_name == "Approved"){ $classstat = "success";}elseif($registers->status_name == "Disqualified"){ $classstat = "danger"; }else{ $classstat = "warning"; }
                                                        @endphp
                                                    <p class="text-{{$classstat}}">{{$registers->status_name}}</p> 
{{--                                                     @if($registers->verify_status !="0")
                                                    <span class="badge badge-primary">Confirmed</span>
                                                    @else
                                                    <span class="badge badge-warning">Pending</span> 
                                                    @endif   --}}
                                                    @endif
                                                </td> 
                                                <td>
                                                    @if($registers->status_id == '9')
                                                      <span><a href="#" class="modalRestore" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" title="Restore"><i class="fa fa-2x fa-refresh"></i><input type="hidden" id="Restoreid" name="Restoreid" value="{{$registers->reg_id}}"></a></span>
                                                      <span><a href="#" class="modalDelete text-danger" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" title="Delete" ><i class="fa fa-2x fa-trash"></i><input type="hidden" id="Delid" name="Delid" value="{{$registers->reg_id}}"></a></span>
                                                    @else
                                                      @if($registers->status_id == '4' || $registers->status_id == '6')
                                                        <span><a href="#" class="modalApproved text-success" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" title="Approved"><i class="fa fa-2x fa-check"></i><input type="hidden" id="Approvedid" name="Approvedid" value="{{$registers->reg_id}}"></a></span>
                                                      @endif
                                                      @if($registers->status_id == '5' || $registers->status_id == '6')
                                                        <span><a href="#" class="modalPending text-warning" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" title="Pending"><i class="fa fa-2x fa-files-o"></i><input type="hidden" id="Pendingid" name="Pendingid" value="{{$registers->reg_id}}"></a></span>
                                                      @endif  
                                                      @if($registers->status_id == '4' || $registers->status_id == '5')
                                                        <span><a href="#" class="modalDisqualified text-danger" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" title="Disqualified"><i class="fa fa-2x fa-remove"></i><input type="hidden" id="Disqualifiedid" name="Disqualifiedid" value="{{$registers->reg_id}}"></a></span>

                                                      @endif
                                                      <span><a href="#" class="modalTrash text-danger" data-hover="tooltip" data-placement="top"  data-toggle="modal"  data-target="#ViewStatus-{{$registers->reg_id}}" title="Move To Trash"><i class="fa fa-2x fa-trash"></i><input type="hidden" id="Trashid" name="Trashid" value="{{$registers->reg_id}}"></a></span>
                                                    @endif
                                                </td> 
                                            </tr>
                                        @endforeach
                                        @else
                                        <tr class='gradeX'>
                                            <td colspan='8' align="center"><strong>No Record Found</strong></td>
                                        </tr>
                                    @endif       

                                    </tbody>
                                </table>
                            </div> <!---.table-responsive-->
                            <div id="paginate" name="paginate">
                                {{ $register->links() }}
                            </div>  
                        </div> 
            </div>
        </div>
    </div>

    @foreach ($register as $registers)

        @php 
        if($registers->status_name == "Approved"){ $classstat = "success";}elseif($registers->status_name == "Disqualified"){ $classstat = "danger"; }else{ $classstat = "warning"; }
        @endphp

        <div class="modal fade" id="ViewStatus-{{$registers->reg_id}}" tabindex="-1" role="dialog"  aria-hidden="true">
          <div class="modal-dialog modal-m">
            <div class="modal-content">
              <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="modal-title">Delete Status</h4>
              </div>
              <div class="modal-body">
                <input type="hidden" id="reg_id_{{$registers->reg_id}}" name="reg_id[]" class="regid" value="{{$registers->reg_id}}">
                <input type="hidden" id="status_now_{{$registers->reg_id}}" name="status_now" value="{{$registers->status_id}}">
                <input type="hidden" id="curr_status_{{$registers->reg_id}}" name="status_current" value="{{$registers->curr_status_id}}">
                <div class="container-fluid">
                  <div class="col-lg-12 for-view" style="display: none;">
                    <form role="form" class="form-horizontal" >
                    {{csrf_field()}}
                      
                        <div class="form-model-stats-box">Status: <span class="text-{{$classstat}}">{{ $registers->status_name }}</span></div>
                    
                        <div class="form-group">
                          <label class="control-label" for="Name">Name</label>
                          <input type="text" class="form-control" id="full_name" name="full_name" placeholder="Enter Name" value="{{ucfirst($registers->rname)}}">
                        </div>

                        <div class="form-group ">
                            <label for="Email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" value="{{$registers->email}}" disabled>
                        </div>
                        
                        <div class="form-group ">
                             <label for="Mobile No">Mobile No</label>
                             <input type="text" class="form-control" id="mob_no" name="mob_no" placeholder="Enter Mobile No" value="{{$registers->mobile_number}}">
                        </div>

                        <div class="form-group ">
                             <label for="bbm_pin">BBM Pin</label>
                             <input type="text" class="form-control" id="bbm_pin" name="bbm_pin" placeholder="Enter BBM Pin" value="{{$registers->pin_bbm}}">
                        </div>
                      
                        <div class="form-group ">
                             <label for="url_permalink">Web Url Entry (*)</label>
                             <div class="input-group m-b"><input type="text" class="form-control" id="url_permalink" name="url_permalink" placeholder="Enter Url Entry" value="{{$registers->url_web_contest}}" disabled><a href="{{$registers->url_web_contest}}" class="input-group-addon" title="click view pages" target="_blank"><i class="fa fa-sign-in"></i></a> </div>
                        </div>
                            
                        <hr>    
                        
                        <div class="form-group ">
                          <label for="bank_name">Your Bank Name</label>
                          <select class="form-control m-b" id="bank_name" name="bank_name" required="" autofocus="" aria-required="true">
                              <option value="">-Select Bank Type-</option>
                              @foreach ($bank as $banks) 
                              <option value="{{$banks->id}}" {{ old('bank_name', $banks->id) == @$registers->bank_id ? 'selected': ''  }} >{{$banks->name}}</option>
                              @endforeach    
                          </select> 
                        </div>

                        <div class="form-group ">
                          <label for="acct_no">Your Account Number</label>
                          <input type="text" class="form-control" id="acct_no" name="acct_no" placeholder="Your Account Number" value="{{$registers->account_no}}"> 
                        </div>

                        <div class="form-group ">
                          <label for="bo_acct">On behalf of the Account</label>
                          <input type="text" class="form-control" id="be_acct" name="be_acct" placeholder="On behalf of the Account" value="{{$registers->behalfofaccount}}"> 
                       </div>

                       <hr>

                       <div class="form-group ">
                         <label for="stat">Confirmation Status</label>
                         <select class="form-control m-b" id="stat" name="stat" required="" autofocus="" aria-required="true" @if($registers->verify_status == "0") disabled @endif>
                             <option value="">-Select Confirmation Status-</option>                               
                            @foreach ($status as $statuses) 
                              <option value="{{$statuses->id}}" {{ old('stat', $statuses->status_name) == @$registers->status_name ? 'selected': ''  }} >{{$statuses->status_name}}</option>
                            @endforeach                                    
                         </select> 
                      </div>

                    </form>   
                  </div>
                  <div class="col-lg-12 for-delete" style="display: none;">
                    <form role="form" class="form-horizontal" >
                    {{csrf_field()}}

                      <div class="form-group"><label>Do You want to Delete This Record?</label></div>
                    </form>   
                  </div> 
                  <div class="col-lg-12 for-restore" style="display: none;">
                  <form role="form" class="form-horizontal" method="post">
                  {{csrf_field()}}
                  <div class="form-group"><label>Do You want to Restore This Record?</label></div>
                  </form>   
                  </div> 
                  <div class="col-lg-12 for-movetrash" style="display: none;">
                    <form role="form" class="form-horizontal" method="post">
                    {{csrf_field()}}
                      <div class="form-group"><label>Do You want to Trash This Record?</label></div>
                    </form>   
                  </div>
                  <div class="col-lg-12 for-moveApproved" style="display: none;">
                    <form role="form" class="form-horizontal" method="post">
                    {{csrf_field()}}

                      <div class="form-group"><label>Do You want to Approved This Record?</label></div>
                    </form>   
                  </div>
                  <div class="col-lg-12 for-movePending" style="display: none;">
                    <form role="form" class="form-horizontal" method="post">
                    {{csrf_field()}}                  
                      <div class="form-group"><label>Do You want to Pending This Record?</label></div>
                    </form>   
                  </div>
                  <div class="col-lg-12 for-moveDisqualified" style="display: none;">
                    <form role="form" class="form-horizontal" method="post">
                    {{csrf_field()}}
                     <div class="form-group"><label>Do You want to Disqualified This Record?</label></div>
                    </form>   
                  </div>
                </div>
              </div>    
              <div class="modal-footer form-model-footer">
                <button type="button" id="cancel" class="btn btn-white" data-dismiss="modal">Cancel</button>
                <button type="button" id="upateConstest" class="btn btn-primary updateBanner" data-dismiss="modal" data-id="{{$registers->reg_id}}">Save</button>
                <button type="button" id="deleteConstest" class="btn btn-danger deleteConstest" data-dismiss="modal" data-id="{{$registers->reg_id}}">Delete</button>
                <button type="button" id="btn-moveActionConstest" class="btn btn-primary restoreBanner btn-moveActionConstest" data-dismiss="modal" data-id="{{$registers->reg_id}}" style="display: none;">Restore</button>
                <button type="button" id="btn-moveActionConstest" class="btn btn-danger trashBanner btn-moveActionConstest" data-dismiss="modal" style="display: none;" data-id="{{$registers->reg_id}}" data-action="9" style="display: none;">Move to Trash</button>
                <button type="button" id="btn-moveActionConstest" class="btn btn-warning pendingBanner btn-moveActionConstest" data-dismiss="modal" style="display: none;" data-id="{{$registers->reg_id}}" data-action="4" style="display: none;">Pending</button>
                <button type="button" id="btn-moveActionConstest" class="btn btn-success approvedBanner btn-moveActionConstest" data-dismiss="modal" style="display: none;" data-id="{{$registers->reg_id}}" data-action="5" style="display: none;">Approved</button>
                <button type="button" id="btn-moveActionConstest" class="btn btn-danger disqualifiedBanner btn-moveActionConstest" data-dismiss="modal" style="display: none;" data-id="{{$registers->reg_id}}" data-action="6" style="display: none;">Disqualified</button>
              </div>

            </div>

          </div>

        </div>

      @endforeach 

@endsection